<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language file.
 *
 * @package   theme_epsilon
 * @copyright 2018 eAbyas Info Solutons Pvt Ltd, India
 * @author    eAbyas  <info@eAbyas.in>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['advancedsettings'] ='Ajustes avanzados';
$string['backgroundimage'] ='Imagen de fondo';
$string['backgroundimage_desc'] ='La imagen que se mostrará como fondo del sitio. La imagen de fondo que cargue aquí anulará la imagen de fondo en sus archivos de tema preestablecido.';
$string['welcometext'] ='Texto de bienvenida';
$string['welcometext_desc']='El texto de bienvenida se mostrará en el texto de bienvenida de inicio de sesión (la longitud no debe tener más de 15 caracteres';
$string['brandcolor'] ='Color de la marca';
$string['brandcolor_desc'] ='El color de acento.';
$string['bootswatch'] ='Bootswatch';
$string['bootswatch_desc'] ='Un bootswatch es un conjunto de variables Bootstrap y CSS para diseñar Bootstrap';
$string['choosereadme'] ='Epsilon es un tema moderno altamente personalizable. Este tema está destinado a usarse directamente o como tema principal al crear nuevos temas utilizando Bootstrap 4.';
$string['currentinparentheses'] ='(Actual)';
$string['configtitle'] ='Épsilon';
$string['fontsize'] ='Tamaño de fuente de la base del tema';
$string['fontsize_desc'] ='Ingrese un tamaño de fuente en%';
$string['generalsettings'] ='Configuración general';
$string['nobootswatch'] ='Ninguna';
$string['customsettings'] ='Ajustes personalizados';
$string['colorsettings'] ='Configuraciones de color';
$string['pluginname'] ='Épsilon';
$string['presetfiles'] ='Archivos preestablecidos de tema adicionales';
$string['presetfiles_desc'] ='Los archivos preestablecidos se pueden utilizar para alterar drásticamente la apariencia del tema. Ver<a href="#">Ajustes preestablecidos de Epsilon</a> para obtener información sobre cómo crear y compartir sus propios archivos preestablecidos, y consulte la <a href="#">Repositorio de presets</a> para presets que otros han compartido.';
$string['preset'] ='Tema preestablecido';
$string['preset_desc'] ='Elija un ajuste preestablecido para cambiar ampliamente el aspecto del tema.';
$string['privacy:metadata'] ='El tema Epsilon no almacena ningún dato personal sobre ningún usuario.';
$string['rawscss'] ='SCSS sin procesar';
$string['rawscss_desc'] ='Utilice este campo para proporcionar código SCSS o CSS que se inyectará al final de la hoja de estilo.';
$string['rawscsspre'] ='SCSS inicial sin procesar';
$string['rawscsspre_desc'] ='En este campo puede proporcionar el código SCSS de inicialización, se inyectará antes que todo lo demás. La mayoría de las veces utilizará esta configuración para definir variables.';
$string['region-side-pre'] ='Correcto';
$string['bodybgcolor'] ='Color de cuerpo bg';
$string['bodybgcolor_desc'] ='El color que agregó aquí se verá afectado como el color de fondo del cuerpo';
$string['privacy:metadata:preference:draweropennav'] ='La preferencia del usuario por ocultar o mostrar la navegación del menú del cajón.';
$string['privacy:drawernavclosed'] ='La preferencia actual por el cajón de navegación está cerrada.';
$string['privacy:drawernavopen'] ='La preferencia actual para el cajón de navegación está abierta.';
$string['customscss'] ='SCSS personalizado';
$string['logocaption'] ='Texto del subtítulo'; 
$string['logocaptiondesc'] ='El texto del título que desea mostrar en el logotipo (la longitud debe ser de 80 caracteres).';
$string['logo'] ='Logotipo de la cabeza'; 
$string['logodesc'] ='El logotipo que cargó aquí se mostrará como un logotipo en el encabezado.';
$string['loginorder'] ='Pedido del formulario de inicio de sesión'; 
$string['loginorder_desc'] ='Puede hacer que el formulario de inicio de sesión se coloque en el lado izquierdo / derecho según su elección';
$string['carousellogo'] ='Logotipo de la página de inicio de sesión en el lado derecho'; 
$string['carousellogo_desc'] ='El logotipo que cargó aquí se mostrará en el control deslizante de la página de inicio de sesión en el lado derecho.';
$string['loginlogo'] ='Logotipo de inicio de sesión de página en el lado izquierdo'; 
$string['loginlogo_desc'] ='El logotipo que cargó aquí se mostrará en el lado de la vida útil de la página de inicio de sesión.';
$string['logindesc'] ='Iniciar sesión Desc'; 
$string['logindesc_desc'] ='El texto que desea que se muestre en la página de inicio de sesión en el lado del control deslizante (la longitud no debe superar los 600 caracteres).';
$string['helpdesc'] ='Ayuda Desc';
$string['helpdesc_desc'] ='El texto que cargó aquí se mostrará cuando haga clic en el botón Ayuda en la página de inicio de sesión';
$string['contact'] ='Contáctenos Desc'; 
$string['contact_desc'] ='El texto que cargó aquí se mostrará cuando haga clic en el botón Contáctenos en la página de inicio de sesión';
$string['aboutus'] ='Sobre nosotros Desc'; 
$string['aboutus_desc'] ='El texto que cargó aquí se mostrará cuando haga clic en el botón Acerca de nosotros en la página de inicio de sesión';
$string['slider1'] ='Control deslizante de inicio de sesión1';
$string['slider1desc'] ='<p class="m-0">Se prefiere la imagen en formato Webp para un mejor rendimiento </p><p></p>La imagen cargada se mostrará como primer control deslizante solo para la página de inicio de sesión';
$string['slider2'] ='Inicio de sesión Slider2';
$string['slider2desc'] ='<p class="m-0">Se prefiere la imagen en formato Webp para un mejor rendimiento </p><p></p>La imagen cargada se mostrará como el segundo control deslizante solo para la página de inicio de sesión';
$string['slider3'] ='Control deslizante de inicio de sesión3';
$string['slider3desc'] ='<p class="m-0">Se prefiere la imagen en formato Webp para un mejor rendimiento </p><p></p>La imagen cargada se mostrará como tercer control deslizante solo para la página de inicio de sesión';
$string['slider4'] ='Control deslizante de inicio de sesión 4';
$string['slider4desc'] ='<p class="m-0">Se prefiere la imagen en formato Webp para un mejor rendimiento </p><p></p>La imagen cargada se mostrará como el cuarto control deslizante solo para la página de inicio de sesión';
$string['slider5'] ='Control deslizante de inicio de sesión5';
$string['slider5desc'] ='<p class="m-0">Se prefiere la imagen en formato Webp para un mejor rendimiento </p><p></p>La imagen cargada se mostrará como el quinto control deslizante solo para la página de inicio de sesión';
$string['favicon'] ='Favicon';
$string['favicondesc'] ='El "icono favorito" de su sitio. Aquí, puede insertar el favicon de su sitio.';
$string['font'] ='Fuente';
$string['font_desc'] ='La fuente seleccionada se aplicará en todo el LMS.';
$string['leftmenu_dashboard'] ='Tablero';
$string['leftmenu_adminstration'] ='Administración';
$string['leftmenu_tm_dashboard'] ='Mi equipo';
$string['showhideblocks'] ='Mostrar / Ocultar bloques';
$string['leftmenu_gmleaderboard'] ='Tabla de clasificación';
$string['region-layerone_full'] ='Capa uno de ancho completo';
$string['region-layerone_one'] ='Capa uno a uno';
$string['region-layerone_two'] ='Capa uno-dos';
$string['region-layertwo_one'] ='Capa dos-uno';
$string['region-layertwo_two'] ='Capa dos-dos';
$string['region-layertwo_three'] ='Capa dos-tres';
$string['region-layertwo_four'] ='Capa dos-cuatro';
$string['region-teamoverview'] ='Equipo';
$string['region-teamdetail_one'] ='Teamdetail uno';
$string['region-teamdetail_two'] ='Teamdetail dos';
$string['region-layerthree_one'] ='Capa tres-uno';
$string['region-layerthree_two'] ='Capa tres-dos';
$string['switchroleto'] ='Cambiar rol a:';
$string['switchroleas'] ='Cambiar rol como ';
$string['show_more_less'] ='Mostrar más / menos';
$string['theme_scheme'] ='Esquema temático';
$string['theme_scheme_desc'] ='El esquema del tema cambia esto para traer muchos cambios de color al sitio';
$string['scheme_1'] ='Esquema 1';
$string['scheme_2'] ='Esquema 2';
$string['scheme_3'] ='Esquema 3';
$string['scheme_4'] ='Esquema 4';
$string['scheme_5'] ='Esquema 5';
$string['scheme_6'] ='Esquema 6';
$string['square'] ='Cuadrado';
$string['rounded'] ='Circulo';
$string['rounded-square'] ='Cuadrado redondeado';
$string['customscheme'] ='Usar esquema personalizado';
$string['left_menu_requests'] ='Gestionar solicitudes';
$string['facebook'] ='Facebook URL';
$string['facebookdesc'] ='La URL que agregó aquí será la ruta de su página de Facebook.';
$string['twitter'] ='URL de Twitter';
$string['twitterdesc'] ='La URL que agregó aquí será la ruta de su página de Twitter.';
$string['linkedin'] ='LinkedIn';
$string['linkedindesc'] ='La URL que agregó aquí será la ruta de su página vinculada';
$string['youtube'] ='URL de Youtube';
$string['youtubedesc'] ='La URL que agregó aquí será la ruta de su página de Youtube.';
$string['instagram'] ='URL de Instagram';
$string['instagramdesc'] ='La URL que agregó aquí será la ruta de su página de Instagram';
$string['footerbgcolor'] ='Color de fondo del pie de página';
$string['footerbg_desc'] ='El color que agregó aquí se verá afectado como el color de fondo del pie de página';
$string['copyright'] ='Derechos de autor';
$string['copyrightdesc'] ='Todo lo que agregue a este área de texto se mostrará en el pie de página en todo su sitio Moodle, por ejemplo, Copyright.';
$string['employee'] ='Empleado';
$string['quickinfo'] ='Información rápida';
$string['quickinfodesc'] ='Informacion rapida';
$string['quickinfo1'] ='Información rápida1';
$string['quickinfo2'] ='Información rápida2';
$string['quickinfo3'] ='Información rápida3';
$string['quickinfo4'] ='Información rápida4';
$string['quickinfo5'] ='Información rápida5';
$string['disable'] ='Inhabilitar';
$string['enable'] ='Habilitar';
$string['region-course-pre'] ='Curso Pre';

$string['manager']='Gerente';
$string['coursecreator']='Creador del curso';
$string['editingteacher']='Profesor';
$string['teacher']='Profesor no editor';
$string['employee']='Empleado';
$string['guest']='Invitado';
$string['user']='Usuario autenticado';
$string['frontpage']='Usuario autenticado en la página principal';
$string['oh']='Jefe de Orginización';
$string['dh']='Jefe de departamento';
$string['tc']='Coordinador de entrenamientos';
$string['trainer']='Entrenador';